/* 
 * File:   main.cpp
 * Author: Xavier Watkins
 *
 * Created on September 23, 2019, 10:28 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;


int main(int argc, char** argv) {

    //Assume pint is a pointer variable. Is each of the following statements valid or
    //invalid? If any is invalid, why?
    //A) pint++;
    //B) −−pint;
    //C) pint /= 2;
    //D) pint *= 4;
    //E) pint += x; // Assume x is an int.
    
    cout << "A) Valid" << endl;
    cout << "B) Valid" << endl;
    cout << "C) Invalid can only do addition and subtraction" << endl;
    cout << "D) Invalid can only do addition and subtraction" << endl;
    cout << "E) Valid" << endl;
            
    return 0;
}

