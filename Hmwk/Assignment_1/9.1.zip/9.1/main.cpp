/* 
 * File:   main.cpp
 * Author: Xavier Watkins
 *
 * Created on September 23, 2019, 10:37 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;


int main(int argc, char** argv) {

   //Write a statement that displays the address of the variable count.
    
    cout << "cout << &count;" << endl;
     
    return 0;
}

