/* 
 * File:   main.cpp
 * Author: Xavier Watkins
 *
 * Created on September 23, 2019, 10:21 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Assume ptr is a pointer to an int and holds the address 12000. On a system with
    //4-byte integers, what address will be in ptr after the following statement?
    //ptr += 10;
    
    cout << "The address is 12040." << endl;
    
    return 0;
}

