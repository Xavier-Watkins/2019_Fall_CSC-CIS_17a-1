/* 
 * File:   main.cpp
 * Author: Xavier Watkins
 *
 * Created on September 23, 2019, 10:07 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;


int main(int argc, char** argv) {

    //Definition Statement for pointer fltPtr
    float *fltPtr;
    
    cout << "The definition statement is, float *fltPtr;" << endl;
    
    return 0;
}

