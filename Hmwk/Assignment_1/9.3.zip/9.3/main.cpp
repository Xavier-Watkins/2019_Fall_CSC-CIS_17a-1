/* 
 * File:   main.cpp
 * Author: Xavier Watkins
 *
 * Created on September 23, 2019, 10:43 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //List three uses of the * symbol in C++.
    
    cout << "1. Multiplication operator." << endl;
    cout << "2. Pointer definition." << endl;
    cout << "3. Indirection operator." << endl;
    
    return 0;
}

