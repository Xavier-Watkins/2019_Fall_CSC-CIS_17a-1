/* 
 * File:   main.cpp
 * Author: Xavier Watkins 
 *
 * Created on September 23, 2019, 10:46 PM
 */

#include <cstdlib>
#include <iostream>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
int *filAray(int,int);
void prntAry(int *,int,int);
void prtMode(int *);
void destroy(int *);
void markSrt(int *,int);
int *mode(int *,int, int);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));

    //Declare all Variables Here
    int size,modVal,perLine,*a1D,*modAray;
    
    //Input or initialize values Here
    size=17;
    modVal=5;
    a1D=filAray(size,modVal);
    
    //Display the unsorted array
    prntAry(a1D,size,modVal);
    
    
    //Process/Calculations Here
    markSrt(a1D,size);
    modAray=mode(a1D,size,modVal);
    
    //Output Located Here
    prntAry(a1D,size,modVal);
    prtMode(a1D);
    
    //Clean up
    destroy(a1D);
    destroy(modAray);

    //Exit
    return 0;
}

void prtMode(int *a){
    
    
}

int *mode(int *a,int n, int m){
    //You write the function
    int *modAray=new int[2]; 
    modAray[0]=0;//Number of modes go here
    modAray[1]=0;//Frequence goes here
    //mode[2 to mode[0]];
    for(int i=0;i<n-1;i++){
        if(*modAray[i]==*modArray[i+1]){
            i++
                    if(i>max){
                        0=i;
                        *modAray=*modAray[i];
                              
                    } 
                    else
                        i=1;
        }
    
    return modAray;
    }
}

void markSrt(int *a,int n){
    for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++){
            if(a[i]>a[j]){
                int temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }
}

void destroy(int *a){
    delete []a;
}

void prntAry(int *a,int n,int perLine){
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
}

int *filAray(int n,int m){
    for(int i=0;i<n;i++){
    n=n<2?2:
      n>1000?1000:n;
    int *array=new int[n];
    for(int i=0;i<n;i++){
        array[i]=i%m;//2 digit numbers
    
    }
    return array;
    }
}
